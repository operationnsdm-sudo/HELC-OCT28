# HELC Oct 28 email assets

1. Push this folder to a **public** GitHub repo (images/ folder at repo root, branch `main`).
2. In `brevo-email.html`, find & replace `YOUR-USERNAME/YOUR-REPO` with your real GitHub user/repo.
3. Brevo > Templates > Create > "Paste your code" > paste the whole file.
